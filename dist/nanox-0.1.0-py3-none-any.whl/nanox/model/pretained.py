from torch.hub import load_state_dict_from_url
import torch.distributed as dist

PRETRAINED_MODEL_URLS = {
  "pcqm4mv1_graphormer_base":"https://ml2md.blob.core.windows.net/graphormer-ckpts/checkpoint_best_pcqm4mv1.pt",
  "pcqm4mv2_graphormer_base":"https://ml2md.blob.core.windows.net/graphormer-ckpts/checkpoint_best_pcqm4mv2.pt",
  "oc20is2re_graphormer3d_base":"https://szheng.blob.core.windows.net/graphormer/modelzoo/oc20is2re/checkpoint_last_oc20_is2re.pt", # this pretrained model is temporarily unavailable
  "pcqm4mv1_graphormer_base_for_molhiv":"https://ml2md.blob.core.windows.net/graphormer-ckpts/checkpoint_base_preln_pcqm4mv1_for_hiv.pt",
}


def load_pretrained_model(model_name):
    if model_name not in PRETRAINED_MODEL_URLS:
        raise ValueError(f"IN load_pretrained_model => UNKOWN model name {model_name}")
    if not dist.is_initialized():
        return load_state_dict_from_url(PRETRAINED_MODEL_URLS[model_name], progress=True)["model"]
    else:
        pretrained_model = load_state_dict_from_url(PRETRAINED_MODEL_URLS[model_name], progress=True, file_name=f"{model_name}_{dist.get_rank()}")["model"]
        dist.barrier()
        return pretrained_model
